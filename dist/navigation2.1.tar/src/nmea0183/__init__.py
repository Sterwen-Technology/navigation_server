#-------------------------------------------------------------------------------
# Name:        package nmea0183
# Purpose:
#
# Author:      Laurent Carré
#
# Created:     26/02/2024
# Copyright:   (c) Laurent Carré Sterwen Technology 2021-2024
# Licence:     Eclipse Public License 2.0
#-------------------------------------------------------------------------------

from .nmea0183_filters import NMEA0183Filter

