#-------------------------------------------------------------------------------
# Name:        package nmea2000_devices
# Purpose:
#
# Author:      Laurent Carré
#
# Created:     13/09/2024
# Copyright:   (c) Laurent Carré Sterwen Technology 2021-2024
# Licence:     Eclipse Public License 2.0
#-------------------------------------------------------------------------------

from .nmea2000_device import AutoPilotEmulator
