# -------------------------------------------------------------------------------
# Name:        global exceptions accross the application
# Purpose:
#
# Author:      Laurent Carré
#
# Created:     02/10/2023
# Copyright:   (c) Laurent Carré Sterwen Technology 2021-2022
# Licence:     Eclipse Public License 2.0
# -------------------------------------------------------------------------------


class ObjectCreationError(Exception):
    pass