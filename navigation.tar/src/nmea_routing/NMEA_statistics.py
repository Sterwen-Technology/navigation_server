#-------------------------------------------------------------------------------
# Name:        NMEA_Statistics
# Purpose:     Compute statistics on NMEA traffic
#
# Author:      Laurent Carré
#
# Created:     25/10/2021
# Copyright:   (c) Laurent Carré Sterwen Technology 2021
# Licence:     <your licence>
#-------------------------------------------------------------------------------



class NMEA183_stats:

    pass
