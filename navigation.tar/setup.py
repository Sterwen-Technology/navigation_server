from setuptools import setup

setup(
    name='navigation_server',
    version='0.931',
    packages=[''],
    url='',
    license='Eclipse Public License 2.0',
    author='Laurent Carré',
    author_email='laurent.carre@sterwen-technology.eu',
    description=''
)
